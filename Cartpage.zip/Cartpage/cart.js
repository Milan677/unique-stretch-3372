// main part

let addtocartdata = JSON.parse(localStorage.getItem("CartData")) || [];



displaycard(addtocartdata);



function displaycard(data) {

    let total = 0;
    document.querySelector("#addedData").innerHTML = null;
    let count = 1;
    //catching part
    let totalprice = document.querySelector("#fav-sum");
    let checkoutsubtotal=document.querySelector("#totalp");
    let totalprodcount=document.querySelector("#fav-total");
    let checkouttotalproducts=document.querySelector("#prod");
    let finaltotalbill=document.querySelector("#ordert");
    let taxonbill=document.querySelector("#tax2");
    //let discount=document.querySelector("#discounttag");

    data.forEach(function (el, i) {

        let div1 = document.createElement("div");
        let div2=document.createElement("div")

        let imageProd = document.createElement("img");
        imageProd.setAttribute("src", el.image)

        
      let title = document.createElement("p")
      title.innerText = el.title

      let desc = document.createElement("p")
      desc.innerText = el.desc
      desc.className = "Ldesc"

      let price = document.createElement("h3")
      price.innerText = el.price
      price.className = "price";

      let qtn = document.createElement("span");
      qtn.textContent = 1;

        let btn1 = document.createElement("p");
        btn1.textContent = "+";
        
        btn1.addEventListener("click", function () {
            count++;
            qtn.textContent = count;
            total = total + Number(el.price);

            totalprice.textContent = total;
            checkoutsubtotal.textContent = total;
            totalprodcount.textContent++;
            checkouttotalproducts.textContent=totalprodcount.textContent;
            
            let x=total*12/100;
            let y=x.toFixed(2)
            taxonbill.textContent=y;
            let a=total+x;
            let b=a.toFixed(2)
            finaltotalbill.textContent=b;
            
            addtocartdata.push(el)

            JSON.parse(localStorage.parse("CartData"));

            localStorage.setItem("CartData",JSON.stringify(addtocartdata))

        })

      

        let btn2 = document.createElement("p");
        btn2.textContent = "-";
        btn2.addEventListener("click", function () {
            if (count <= 1) {
                let cartdata = JSON.parse(localStorage.getItem("CartData")) || [];
                cartdata.splice(i, 1);
                localStorage.setItem("CartData", JSON.stringify(cartdata));
                displaycard(cartdata);
            } else {
                count--;
                qtn.textContent = count;
                total = total - Number(el.price)
                totalprice.textContent = total;
                checkoutsubtotal.textContent = total;
                totalprodcount.textContent--;
                checkouttotalproducts.textContent=totalprodcount.textContent;
                let x=total*12/100;
                let y=x.toFixed(2)
                taxonbill.textContent=y;
                let a=total+x;
                let b=a.toFixed(2)
                finaltotalbill.textContent=b;
                
            }

        })


        let btn = document.createElement("button");
        btn.textContent = "Remove";
        btn.addEventListener("click", function () {

            let cartdata = JSON.parse(localStorage.getItem("CartData")) || [];
            cartdata.splice(i, 1);
            localStorage.setItem("CartData", JSON.stringify(cartdata));
            displaycard(cartdata);
        })

        total = total + Number(el.price);


        totalprice.textContent = total;
        checkoutsubtotal.textContent = total;
         totalprodcount.textContent=data.length;
         checkouttotalproducts.textContent=data.length;
        let x=total*12/100;
        let y=x.toFixed(2)
        taxonbill.textContent=y;
        let a=total+x;
        let b=a.toFixed(2)
        finaltotalbill.textContent=b;

        div2.append(btn1, qtn, btn2)
        div1.append(imageProd, title, desc, price, div2, btn);
        
        document.querySelector("#addedData").append(div1);


    })


    let dis = document.querySelector("#discounttag");
    dis.addEventListener("submit", function (event) {

        event.preventDefault();
        let val = document.querySelector("#cupon-filled").value;
        // console.log(val)
        if (val === "combo40") {
            finaltotalbill.textContent = Math.floor(total - (total * 0.2));
            // console.log(totalprice)
            localStorage.setItem("disprice", totalprice.textContent)


        } else {
            alert("You Enter The Wrong Coupen Code")
        }


    })



}












































// let totalproduct=document.querySelector("#fav-total");
// let checkouttoal = document.querySelector("#prod");
// let count = 1;
// let total = 0;
// if (addtocartdata.length == 0) {
//   document.querySelector("#empty-cart").textContent = "Your cart is Empty"
// } else {

//   displyaCart(addtocartdata);



//   function displyaCart(data) {

//     let totalCost = document.querySelector("#totalp");
//     let totalofprod = document.querySelector("#fav-sum");
//     let taxonbill = document.querySelector("#tax2");
//     let totalorder = document.querySelector("#ordert");
    
//     let sum = 0;
//     document.querySelector("#addedData").textContent = null;
//     data.forEach((element, index) => {

//       let div1 = document.createElement("div");
//       let div2 = document.createElement("div");
//       let imgdiv = document.createElement("img")
//       imgdiv.setAttribute("src", element.image)


//       let title = document.createElement("p")
//       title.innerText = element.title

//       let desc = document.createElement("p")
//       desc.innerText = element.desc
//       desc.className = "Ldesc"

//       let price = document.createElement("h3")
//       price.innerText = element.price
//       price.className = "price";

//       let increse = document.createElement("p");
//       increse.innerText = "+";


//       increse.addEventListener("click", function () {
//             count++;
//             qtn.textContent = count;
//             total = total + Number(element.price)
//             totalCost.textContent =total;
//             totalproduct.innerText++;
//             checkouttoal.innerText++;
//       })


//       let qtn = document.createElement("span");
//       qtn.innerText = 1;

//       let decrease = document.createElement("p");
//       decrease.innerText = "-";

//       decrease.addEventListener("click", function () {
//         if (count <= 1) {
//           let cartdata = JSON.parse(localStorage.getItem("cart")) || [];
//           addtocartdata.splice(i, 1);
//           localStorage.setItem("cart", JSON.stringify(cartdata));
//           displyaCart(cartdata);
//       } else {
//           count--;
//           qtn.textContent = count;
//           total = total - Number(element.price)
//           totalCost.textContent = +total;
//           totalproduct.innerText--;
//           checkouttoal.innerText--;
//       }

//       })




//       let btn = document.createElement("button");
//       btn.innerText = "Delete";

//       btn.addEventListener("click", function () {
//         let addtocartdata = JSON.parse(localStorage.getItem("CartData")) || [];

//         addtocartdata.splice(index, 1);


//         displyaCart(addtocartdata)

//         localStorage.setItem("CartData", JSON.stringify(addtocartdata))
//       })

//       div2.append(increse, qtn, decrease)
//       div1.append(imgdiv, title, desc, price, div2, btn);

//       document.querySelector("#addedData").append(div1);

//       sum += Number(element.price);
//     });



//     document.querySelector("#fav-sum").innerText = sum;
//     document.querySelector("#fav-total").innerText = data.length;

//     document.querySelector("#prod").innerText = data.length;


//     document.querySelector("#totalp").innerText = sum;
//     document.querySelector("#tax2").innerText = sum * 12 / 100;
//     let n = sum + (sum * 12 / 100);
//     let z = n.toFixed(2)
//     document.querySelector("#ordert").innerText = z
//   }


// }

